1. Open VS code
2. Run the requirements.txt file
3. Run the Engine file - python Engine.py